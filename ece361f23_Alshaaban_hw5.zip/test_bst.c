#include <stdio.h>
#include "bst.h"
#include <time.h>
#include "iom361_r2.h"
#include <math.h>

void handle_userinput() {
    struct temp_humid_data array[31];
    int size = 0; // not what the actuall till user specifies
    // let us take reading for whole month
    int start, end;
    printf("start day for reading from now e.g 0 means today: ");
    scanf("%d",&start);

    printf("enter last day of reading from now e.g 30 means 31st day: ");    
    scanf("%d",&end);

    if (end-start > 31) {
        printf("month is max 31 days\n");
        exit(1);
    }
    simulate_take_temp_humid_readings(start, end, array, &size);
    struct bst_node *root = new_bst(array[0]); // initialize the node
    populateBST(root, array, size);
    //inorder_print(root);
    
    
    int choice = 0;
    while (1) {
        printf("select from the following options\n");
        printf("0: find readings of nth day: \n");
        printf("enter non zero to print readings in sorted order and exit: ");
        if (scanf("%d", &choice) != 0) {
            // If the user presses Enter without entering a number, exit            
            if (choice != 0) {
                inorder_print(root);
                break;            
            } else {
                printf("enter nth day's from now: ");
                scanf("%d", &choice);
                struct bst_node *node = search_bst(root, choice);
                if (node != NULL) {
                    printf("---------------------------\n");
                    print_th(node->th);
                    printf("---------------------------\n");
                } else {
                    printf("failed to find timestamp of this date...\n");
                }
            }
        } else {
            printf("wrong input\n");
        }
    }
}
int main(int argc, char *argv[]) {
    
    handle_userinput();
    return 0;
}
