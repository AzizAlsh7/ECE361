#ifndef BST_H
#include <stdlib.h>
#include <stdint.h>

struct temp_humid_data {
    time_t timestamp;
    uint32_t temp;
    u_int32_t humid;
};

void simulate_take_temp_humid_readings(int start_day, int end_day, struct temp_humid_data *array, int *size);
struct temp_humid_data new_temp_humid(u_int32_t t, u_int32_t h, time_t s);
void print_th(struct temp_humid_data th);

struct bst_node {
    struct temp_humid_data th;    
    struct bst_node *left;
    struct bst_node *right;
};

struct bst_node* new_bst(struct temp_humid_data th);

// inserts temp and humidity to bst tree
void bst_insert(struct bst_node* root, struct temp_humid_data th);

void inorder_print(struct bst_node* root);

// it is used to shuffle array so that near perfect bst could be formed
// otherwise the chances are the bst will be lilke the linked list
// so linearity reduces the performace during searching
void shuffle_array(struct temp_humid_data *array, int size);

// start and end of the day in the calender
void populateBST(struct bst_node *root, struct temp_humid_data *array,
                 int size);

// day 1, day 2..... day n
// month will not taken because month will be the one we are running the
// aplication
struct bst_node *search_bst(struct bst_node *root, int day);
struct bst_node *search_timestamp_bst(struct bst_node *root, time_t key);


#define BST_H
#endif
